-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 12, 2021 at 06:15 AM
-- Server version: 10.4.19-MariaDB
-- PHP Version: 7.4.20

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `employee`
--

-- --------------------------------------------------------

--
-- Table structure for table `employee`
--

CREATE TABLE `employee` (
  `first name` varchar(20) NOT NULL,
  `second Name` varchar(30) NOT NULL,
  `email address` varchar(20) NOT NULL,
  `Gender` varchar(20) NOT NULL,
  `Position` varchar(30) NOT NULL,
  `ID Number` varchar(20) NOT NULL,
  `Phone Number` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `employee`
--

INSERT INTO `employee` (`first name`, `second Name`, `email address`, `Gender`, `Position`, `ID Number`, `Phone Number`) VALUES
('gfgesddfj', 'b,flfd', 'fvdj', 'Male', 'Accounts', '44555', '2115155'),
('kennie', 'mwendwa', 'ken@gmail.com', 'Male', 'manager', '634873267', '703546375'),
('edwfrgth', 'efrgtbnh', 'refgtrt', 'Male', 'manager', '6543245', '4567543'),
('jhbewwd', 'sss', 'eee', 'Female', 'manager', 'ew', 'q222232'),
('fwefe', 'dewew', 'dsfewfer', 'Male', 'manager', 'ewfewfc', 'dweffe');

-- --------------------------------------------------------

--
-- Table structure for table `more`
--

CREATE TABLE `more` (
  `ID Number` int(100) NOT NULL,
  `Date Entered` text NOT NULL,
  `Education` varchar(100) NOT NULL,
  `Experience` varchar(100) NOT NULL,
  `Salary` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `more`
--

INSERT INTO `more` (`ID Number`, `Date Entered`, `Education`, `Experience`, `Salary`) VALUES
(44555, '2021-09-09', 'PHD', '1 year', 40000);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `employee`
--
ALTER TABLE `employee`
  ADD PRIMARY KEY (`ID Number`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
